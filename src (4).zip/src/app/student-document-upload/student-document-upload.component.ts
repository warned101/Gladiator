import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-student-document-upload',
  templateUrl: './student-document-upload.component.html',
  styleUrls: ['./student-document-upload.component.css']
})
export class StudentDocumentUploadComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
