import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-student-bank-details',
  templateUrl: './student-bank-details.component.html',
  styleUrls: ['./student-bank-details.component.css']
})
export class StudentBankDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
