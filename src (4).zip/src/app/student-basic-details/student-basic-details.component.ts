import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-student-basic-details',
  templateUrl: './student-basic-details.component.html',
  styleUrls: ['./student-basic-details.component.css']
})
export class StudentBasicDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
