import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-student-dashboard-component',
  templateUrl: './student-dashboard-component.component.html',
  styleUrls: ['./student-dashboard-component.component.css']
})
export class StudentDashboardComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
