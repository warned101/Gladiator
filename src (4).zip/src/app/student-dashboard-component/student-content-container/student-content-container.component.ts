import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-student-content-container',
  templateUrl: './student-content-container.component.html',
  styleUrls: ['./student-content-container.component.css']
})
export class StudentContentContainerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
