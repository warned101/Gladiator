import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-student-academic-details',
  templateUrl: './student-academic-details.component.html',
  styleUrls: ['./student-academic-details.component.css']
})
export class StudentAcademicDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
