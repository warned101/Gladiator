import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bannercomponent',
  templateUrl: './bannercomponent.component.html',
  styleUrls: ['./bannercomponent.component.css']
})
export class BannercomponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
