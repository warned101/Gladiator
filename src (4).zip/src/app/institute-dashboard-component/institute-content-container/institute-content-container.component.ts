import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-institute-content-container',
  templateUrl: './institute-content-container.component.html',
  styleUrls: ['./institute-content-container.component.css']
})
export class InstituteContentContainerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
