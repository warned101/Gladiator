import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-institute-dashboard-component',
  templateUrl: './institute-dashboard-component.component.html',
  styleUrls: ['./institute-dashboard-component.component.css']
})
export class InstituteDashboardComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
