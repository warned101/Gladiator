import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ministery-dashboard-component',
  templateUrl: './ministery-dashboard-component.component.html',
  styleUrls: ['./ministery-dashboard-component.component.css']
})
export class MinisteryDashboardComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
