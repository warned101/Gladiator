import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-minister-content-container',
  templateUrl: './minister-content-container.component.html',
  styleUrls: ['./minister-content-container.component.css']
})
export class MinisterContentContainerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
