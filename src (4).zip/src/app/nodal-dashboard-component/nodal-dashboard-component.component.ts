import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nodal-dashboard-component',
  templateUrl: './nodal-dashboard-component.component.html',
  styleUrls: ['./nodal-dashboard-component.component.css']
})
export class NodalDashboardComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
