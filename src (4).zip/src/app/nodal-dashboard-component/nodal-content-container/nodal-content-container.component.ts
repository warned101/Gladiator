import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nodal-content-container',
  templateUrl: './nodal-content-container.component.html',
  styleUrls: ['./nodal-content-container.component.css']
})
export class NodalContentContainerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
