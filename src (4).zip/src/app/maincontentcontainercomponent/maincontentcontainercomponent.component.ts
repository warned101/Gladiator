import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-maincontentcontainercomponent',
  templateUrl: './maincontentcontainercomponent.component.html',
  styleUrls: ['./maincontentcontainercomponent.component.css']
})
export class MaincontentcontainercomponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
