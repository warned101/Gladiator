import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-institute-register-component',
  templateUrl: './institute-register-component.component.html',
  styleUrls: ['./institute-register-component.component.css']
})
export class InstituteRegisterComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
