import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-student-register-component',
  templateUrl: './student-register-component.component.html',
  styleUrls: ['./student-register-component.component.css']
})
export class StudentRegisterComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
