import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sidecomponent',
  templateUrl: './sidecomponent.component.html',
  styleUrls: ['./sidecomponent.component.css']
})
export class SidecomponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
